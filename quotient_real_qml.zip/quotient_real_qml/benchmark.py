import argparse
import json
from pathlib import Path
import time
import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import MinMaxScaler
from qreal_vqc import RealVQC


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--splits", type=int, default=5); ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--epochs", type=int, default=20); ap.add_argument("--qubits", type=int, default=4)
    ap.add_argument("--layers", type=int, default=2); ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--output", default="results"); args = ap.parse_args()
    x, y = load_breast_cancer(return_X_y=True)
    cv = RepeatedStratifiedKFold(n_splits=args.splits, n_repeats=args.repeats, random_state=args.seed)
    rows = []
    for fold, (tr, te) in enumerate(cv.split(x, y), 1):
        prep = make_pipeline(MinMaxScaler(), PCA(args.qubits, random_state=args.seed + fold),
                             MinMaxScaler(feature_range=(-np.pi, np.pi)))
        xtr, xte = prep.fit_transform(x[tr]), prep.transform(x[te])
        for backend in ["complex", "structured_real", "naive_real"]:
            model = RealVQC(args.qubits, args.layers, backend, args.seed + fold)
            start = time.perf_counter(); model.fit(xtr, y[tr], args.epochs, verbose=False)
            train_s = time.perf_counter() - start
            start = time.perf_counter(); prob = model.probabilities(xte); pred = prob.argmax(1)
            infer_ms = (time.perf_counter() - start) * 1000
            rows.append({"fold": fold, "model": backend,
                         "accuracy": accuracy_score(y[te], pred),
                         "f1_weighted": f1_score(y[te], pred, average="weighted"),
                         "roc_auc": roc_auc_score(y[te], prob[:, 1]),
                         "parameters": model.n_parameters, "training_time_s": train_s,
                         "inference_time_ms": infer_ms})
            print(f"fold={fold:02d} {backend:15s} acc={rows[-1]['accuracy']:.3f}")
    raw = pd.DataFrame(rows)
    summary = raw.groupby("model")[["accuracy", "f1_weighted", "roc_auc", "parameters",
                                     "training_time_s", "inference_time_ms"]].agg(["mean", "std"])
    out = Path(args.output); out.mkdir(exist_ok=True, parents=True)
    raw.to_csv(out / "fold_results.csv", index=False); summary.to_csv(out / "summary.csv")
    (out / "protocol.json").write_text(json.dumps(vars(args), indent=2))
    print(summary)


if __name__ == "__main__": main()

