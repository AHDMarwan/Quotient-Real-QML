# Structured-real QML prototype

This Colab-ready project compares a standard complex variational quantum
classifier, its exactly equivalent structured-real representation, and a
same-parameter naive real-amplitude circuit.

```bash
pip install -r requirements.txt
python -m unittest -v
python demo.py
python benchmark.py --splits 5 --repeats 3 --epochs 20
```

The key validation is that, at identical parameters, complex and
structured-real predictions agree to numerical precision. The structured-real
backend stores `[Re(psi), Im(psi)]` and never uses complex arithmetic. The naive
real backend replaces phase rotations with additional real rotations.

This is a first realification prototype inspired by the quotient-space theory;
it must not be described as a complete implementation of the paper's full
multipartite quotient construction. A next theoretical step is to express and
test balanced/quotient composition explicitly.

Source: Barrios Hita et al., *Quantum Mechanics Based on Real Numbers: A
Consistent Description*, Physical Review Letters 136, 240202 (2026),
https://doi.org/10.1103/4k13-sdjh and https://arxiv.org/abs/2503.17307
