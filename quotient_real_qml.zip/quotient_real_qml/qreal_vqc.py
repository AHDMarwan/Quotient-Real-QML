"""Complex, structured-real, and naive-real variational classifiers.

This is a small exact state-vector research simulator.  The ``structured_real``
backend stores [Re(psi), Im(psi)] and performs only real arithmetic.  It is the
realification of the complex circuit, not yet a full implementation of every
multipartite quotient-space construction in Barrios Hita et al. (2026).
"""
from __future__ import annotations
import numpy as np


def ry(theta):
    c, s = np.cos(theta / 2), np.sin(theta / 2)
    return np.array([[c, -s], [s, c]], dtype=float)


def rz(theta):
    return np.diag([np.exp(-0.5j * theta), np.exp(0.5j * theta)])


def apply_local(states, gate, qubit, n_qubits):
    """Apply a 2x2 gate to a batch; qubit 0 is the least-significant bit."""
    batch = len(states)
    shaped = states.reshape(batch, *([2] * n_qubits))
    axis = n_qubits - qubit
    moved = np.moveaxis(shaped, axis, -1)
    moved = np.einsum("...a,ba->...b", moved, gate, optimize=True)
    return np.moveaxis(moved, -1, axis).reshape(batch, -1)


def apply_cnot(states, control, target):
    dim = states.shape[1]
    indices = np.arange(dim)
    perm = indices.copy()
    active = ((indices >> control) & 1).astype(bool)
    perm[active] ^= 1 << target
    return states[:, perm]


class RealVQC:
    VALID_BACKENDS = {"complex", "structured_real", "naive_real"}

    def __init__(self, n_qubits=4, layers=2, backend="structured_real", seed=7):
        if backend not in self.VALID_BACKENDS:
            raise ValueError(f"backend must be one of {self.VALID_BACKENDS}")
        self.n_qubits, self.layers, self.backend = n_qubits, layers, backend
        rng = np.random.default_rng(seed)
        # Two angles per qubit/layer for matched parameter counts.
        self.theta = rng.normal(0, 0.15, size=(layers, n_qubits, 2))

    @property
    def n_parameters(self): return self.theta.size

    def _zero_state(self, batch):
        dim = 2**self.n_qubits
        if self.backend == "complex":
            state = np.zeros((batch, dim), dtype=complex); state[:, 0] = 1
            return state
        # Concatenated real and imaginary components.
        state = np.zeros((batch, 2 * dim), dtype=float); state[:, 0] = 1
        return state

    def _realified_gate(self, state, gate, q):
        dim = 2**self.n_qubits
        x, y = state[:, :dim], state[:, dim:]
        a, b = gate.real, gate.imag
        new_x = apply_local(x, a, q, self.n_qubits) - apply_local(y, b, q, self.n_qubits)
        new_y = apply_local(x, b, q, self.n_qubits) + apply_local(y, a, q, self.n_qubits)
        return np.concatenate((new_x, new_y), axis=1)

    def _gate(self, state, gate, q):
        if self.backend == "complex":
            return apply_local(state, gate, q, self.n_qubits)
        if self.backend == "structured_real":
            return self._realified_gate(state, gate, q)
        dim = 2**self.n_qubits
        x = apply_local(state[:, :dim], np.asarray(gate).real, q, self.n_qubits)
        y = apply_local(state[:, dim:], np.asarray(gate).real, q, self.n_qubits)
        return np.concatenate((x, y), axis=1)

    def _cnot(self, state, control, target):
        if self.backend == "complex": return apply_cnot(state, control, target)
        dim = 2**self.n_qubits
        return np.concatenate((apply_cnot(state[:, :dim], control, target),
                               apply_cnot(state[:, dim:], control, target)), axis=1)

    def probabilities(self, angles):
        angles = np.asarray(angles, dtype=float)
        if angles.shape[1] != self.n_qubits:
            raise ValueError("angles must have n_qubits columns")
        state = self._zero_state(len(angles))
        # Real data encoding shared by all three models; batched angles require
        # sample-wise gates, implemented with closed-form pair updates.
        state = self._encode_batch(state, angles)
        for layer in range(self.layers):
            for q in range(self.n_qubits):
                state = self._gate(state, ry(self.theta[layer, q, 0]), q)
                second = rz(self.theta[layer, q, 1]) if self.backend != "naive_real" else ry(self.theta[layer, q, 1])
                state = self._gate(state, second, q)
            for q in range(self.n_qubits - 1): state = self._cnot(state, q, q + 1)
            if self.n_qubits > 2: state = self._cnot(state, self.n_qubits - 1, 0)
        dim = 2**self.n_qubits
        if self.backend == "complex": weights = np.abs(state)**2
        else: weights = state[:, :dim]**2 + state[:, dim:]**2
        mask = ((np.arange(dim) >> 0) & 1).astype(bool)
        p1 = weights[:, mask].sum(axis=1)
        return np.column_stack((1 - p1, p1))

    def _encode_batch(self, state, angles):
        """Apply sample-dependent RY gates without Python loops over samples."""
        dim = 2**self.n_qubits
        complex_mode = self.backend == "complex"
        parts = [state] if complex_mode else [state[:, :dim], state[:, dim:]]
        output = []
        for part in parts:
            for q in range(self.n_qubits):
                shaped = part.reshape(len(part), *([2] * self.n_qubits))
                axis = self.n_qubits - q
                moved = np.moveaxis(shaped, axis, -1)
                c, s = np.cos(angles[:, q] / 2), np.sin(angles[:, q] / 2)
                view = (len(part),) + (1,) * (moved.ndim - 2)
                c, s = c.reshape(view), s.reshape(view)
                a, b = moved[..., 0], moved[..., 1]
                moved = np.stack((c * a - s * b, s * a + c * b), axis=-1)
                part = np.moveaxis(moved, -1, axis).reshape(len(part), -1)
            output.append(part)
        return output[0] if complex_mode else np.concatenate(output, axis=1)

    def predict(self, x): return self.probabilities(x).argmax(axis=1)

    def fit(self, x, y, epochs=20, lr=0.05, verbose=True):
        m = np.zeros_like(self.theta); v = np.zeros_like(self.theta)
        history = []
        for epoch in range(1, epochs + 1):
            p = np.clip(self.probabilities(x)[:, 1], 1e-7, 1 - 1e-7)
            loss = -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))
            dloss_dp = (p - y) / (p * (1 - p) * len(y))
            grad = np.zeros_like(self.theta)
            for idx in np.ndindex(*self.theta.shape):
                old = self.theta[idx]
                self.theta[idx] = old + np.pi / 2; plus = self.probabilities(x)[:, 1]
                self.theta[idx] = old - np.pi / 2; minus = self.probabilities(x)[:, 1]
                self.theta[idx] = old
                grad[idx] = np.sum(dloss_dp * 0.5 * (plus - minus))
            m = .9 * m + .1 * grad; v = .999 * v + .001 * grad**2
            mh, vh = m / (1 - .9**epoch), v / (1 - .999**epoch)
            self.theta -= lr * mh / (np.sqrt(vh) + 1e-8)
            acc = np.mean(self.predict(x) == y)
            history.append({"epoch": epoch, "loss": float(loss), "accuracy": float(acc)})
            if verbose and (epoch == 1 or epoch % 5 == 0 or epoch == epochs):
                print(f"{self.backend:15s} epoch={epoch:03d} loss={loss:.4f} acc={acc:.3f}")
        return history
