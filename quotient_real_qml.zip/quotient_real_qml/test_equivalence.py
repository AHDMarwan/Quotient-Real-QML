import unittest
import numpy as np
from qreal_vqc import RealVQC, rz


class TestRealification(unittest.TestCase):
    def test_gate_block_structure(self):
        u = rz(.37); a, b = u.real, u.imag
        real_u = np.block([[a, -b], [b, a]])
        j = np.block([[np.zeros((2, 2)), -np.eye(2)], [np.eye(2), np.zeros((2, 2))]])
        np.testing.assert_allclose(real_u @ j, j @ real_u, atol=1e-14)
        np.testing.assert_allclose(real_u.T @ real_u, np.eye(4), atol=1e-14)

    def test_complex_and_structured_real_predictions(self):
        rng = np.random.default_rng(11)
        x = rng.uniform(-np.pi, np.pi, size=(9, 4))
        complex_model = RealVQC(4, 2, "complex", seed=3)
        real_model = RealVQC(4, 2, "structured_real", seed=99)
        real_model.theta = complex_model.theta.copy()
        np.testing.assert_allclose(complex_model.probabilities(x),
                                   real_model.probabilities(x), atol=2e-13)


if __name__ == "__main__": unittest.main()

