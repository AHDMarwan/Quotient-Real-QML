import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import MinMaxScaler
from qreal_vqc import RealVQC

x, y = load_breast_cancer(return_X_y=True)
xtr, xte, ytr, yte = train_test_split(x, y, test_size=.25, stratify=y, random_state=7)
prep = make_pipeline(MinMaxScaler(), PCA(n_components=4, random_state=7),
                     MinMaxScaler(feature_range=(-np.pi, np.pi)))
xtr, xte = prep.fit_transform(xtr), prep.transform(xte)

models = {}
for backend in ["complex", "structured_real", "naive_real"]:
    model = RealVQC(n_qubits=4, layers=2, backend=backend, seed=7)
    model.fit(xtr, ytr, epochs=20, lr=.05)
    models[backend] = model
    print(backend, "test accuracy:", np.mean(model.predict(xte) == yte))

# The independently trained solutions can differ. Exact equivalence is tested
# by copying the same parameters between complex and structured-real models.
models["structured_real"].theta = models["complex"].theta.copy()
error = np.max(np.abs(models["complex"].probabilities(xte) -
                      models["structured_real"].probabilities(xte)))
print("maximum complex/structured-real prediction error:", error)

